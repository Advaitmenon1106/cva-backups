import os
import numpy as np
# from skimage.feature import hog, SIFT, ORB
# from skimage.color import rgb2gray
# from skimage.io import imread
import cv2 
import imutils

bgsub = cv2.createBackgroundSubtractorMOG2(detectShadows=False)


# cap = cv2.VideoCapture('./shibuya.mp4')
cap = cv2.VideoCapture(0)

ret, prev = cap.read()
prev_grey = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)

while True:
    ret, frame = cap.read()

    if frame is None:
        break

    cv2.imshow('', frame)

    diff_col = cv2.absdiff(frame, prev)
    cv2.imshow('color diff', diff_col)
    prev = frame.copy()
    

    fgmask = bgsub.apply(frame)
    cv2.imshow('mask', fgmask)

    grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    diff = cv2.absdiff(grey, prev_grey)

    _, t = cv2.threshold(diff, 35, 255, cv2.THRESH_OTSU)
    cv2.imshow('diff', diff)
    cv2.imshow('thresholded', t)

    prev_grey = grey.copy()

    cv2.waitKey(1)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
