import cv2

import numpy as np

def local_binary_patterns(image, radius=1, points=8):
  """
  This function computes the local binary pattern (LBP) for a grayscale image.

  Args:
      image: Grayscale image as a NumPy array.
      radius: Radius of the neighborhood to consider (default: 1).
      points: Number of points in the neighborhood (default: 8).

  Returns:
      A NumPy array of the same size as the input image, containing the LBP values for each pixel.
  """

  # Check for grayscale image
  if len(image.shape) != 2:
    raise ValueError("Input image must be grayscale (single channel).")

  # Pad the image to ensure no out-of-bounds access during calculation
  height, width = image.shape
  padded_image = cv2.copyMakeBorder(image, radius, radius, radius, radius, cv2.BORDER_REPLICATE)

  # Initialize output LBP image
  lbp_image = np.zeros((height, width), dtype=np.uint8)

  for y in range(radius, height + radius):
    for x in range(radius, width + radius):
      center = padded_image[y, x]

      # Get neighbors in a circular pattern
      neighbors = []
      for i in range(points):
        theta = i * 2 * np.pi / points
        dx = int(radius * np.cos(theta))
        dy = int(radius * np.sin(theta))
        neighbor_pixel = padded_image[y + dy, x + dx]
        neighbors.append(neighbor_pixel)

      # Threshold and compute binary code
      binary = np.array([0 if p < center else 1 for p in neighbors], dtype=np.uint8)
      # Invert for traditional LBP (optional)
      # binary = 1 - binary

      # Convert binary to decimal using power of 2 weights
      decimal_code = np.sum(binary * 2**np.arange(points - 1, -1, -1))

      # Assign LBP value to output image
      lbp_image[y - radius, x - radius] = decimal_code

  return lbp_image

# Example usage
image = cv2.imread("./pexels-saleh-badawi-20852704.jpg", cv2.IMREAD_GRAYSCALE)
lbp = local_binary_patterns(image)

# Display LBP image
cv2.imshow("LBP Image", lbp)
cv2.waitKey(0)
cv2.destroyAllWindows()
