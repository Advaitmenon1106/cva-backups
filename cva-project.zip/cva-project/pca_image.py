import cv2
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import imutils

# image = plt.imread('./pexels-saleh-badawi-20852704.jpg')
image = plt.imread('./pexels-icecloud.jpg')

im_2 = imutils.resize(image, width=500)
lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
imgray = cv2.cvtColor(im_2, cv2.COLOR_BGR2GRAY)
# lab = cv2.resize(lab, dsize=(900, 900))

# cv2.imshow('', image)

# ret, thresh = cv2.threshold(imgray, 100, 200, 0)
# contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
# cv2.drawContours(im_2, contours, -1, (0,255,0), 3)

# edge = cv2.Canny(image, 40, 200)


# blobDetector = cv2.SimpleBlobDetector_create()
# keypoints = blobDetector.detect(im_2)
# im_with_keypoints = cv2.drawKeypoints(im_2, keypoints, np.array([]), (0,0,255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

# saliencyMapper = cv2.saliency.MotionSaliencyBinWangApr2014_create()
# saliencyMapper.setImageSize()
# print(computed)


# cv2.imshow('', cv2.resize(lab, dsize=(900, 900)))

cv2.imshow('', im_2)

# cv2.imshow('', im_with_keypoints)
# cv2.imshow('', cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
# cv2.imshow('', edge)

if (cv2.waitKey(0)):
    cv2.destroyAllWindows()

# image_flattened = image.reshape(image.shape[0], image.shape[1]*image.shape[2])

# pca = PCA().fit(image_flattened)
# pca_image = pca.transform(image_flattened)

# plt.imshow(im_with_keypoints)
# plt.imshow(pca_image.reshape(image.shape[0], image.shape[1], image.shape[2]))
# plt.show()

