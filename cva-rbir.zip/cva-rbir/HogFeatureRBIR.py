import cv2
import os
from skimage.io import imread
from skimage.feature import hog
from skimage.color import rgb2gray
import json
import imutils

key_value = {}

c= 0

for img_path in os.listdir('./training'):

    if c==20:
        break
    try: greyscale = imread(f'./training/{img_path}')
    except:print(img_path)

    if len(greyscale.shape)>2:
        greyscale = rgb2gray(greyscale)

    greyscale = imutils.resize(greyscale, width=128)

    hog_ft = hog(greyscale)
    key_value[c] = [img_path, list(hog_ft)]
    c+=1


with open(f'./features/feature_db.json', 'w') as f:
    json.dump(key_value, f)
    f.close()
