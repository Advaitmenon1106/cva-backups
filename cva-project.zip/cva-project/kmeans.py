import cv2
import imutils
import numpy as np
# Load the image
image = cv2.imread("./pexels-icecloud.jpg")
image = imutils.resize(image, width=500)

# Convert to grayscale (optional, adjust based on your image properties)
gray = cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)

# Define the number of clusters (experiment with different values)
num_clusters = 5

# Perform K-Means clustering
# kmeans = cv2.kmeans(gray.reshape(-1,1), num_clusters, None, cv2.KMEANS_RANDOM_CENTERS, 10, criteria=(cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0))
kmeans = cv2.kmeans(data=gray.reshape(-1, 1).astype(np.float32), K=num_clusters, bestLabels=None, criteria=(cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0), attempts=10, flags=cv2.KMEANS_RANDOM_CENTERS)

# Get labels (cluster assignments) for each pixel
labels = kmeans[1].flatten()

# Get the resulting cluster centers
centers = kmeans[0]

# Segment the image based on cluster labels
segmented_image = cv2.cvtColor(labels.reshape(gray.shape), cv2.COLOR_GRAY2BGRA)

# Visualize the original image and segmentation
cv2.imshow("Original Image", image)
cv2.imshow("Segmented Image", segmented_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Further steps to identify ROIs:

# 1. Analyze the cluster centers: 
# You can explore the color or intensity values of the centers to understand the 
# characteristics of each cluster.

# 2. Filter based on area or other properties:
# Loop through each cluster label and identify connected regions. 
# You can filter these regions based on minimum area, aspect ratio, or other 
# properties to potentially identify relevant ROIs.

# This is a basic example. You'll need to implement additional logic to refine 
# the identified ROIs based on your project requirements.
