import cv2
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
import os
from skimage.io import imread
from skimage.feature import hog
from skimage.color import rgb2gray
from skimage.metrics import mean_squared_error, hausdorff_pair, adapted_rand_error

uri = "mongodb+srv://advait:W2WqMRvD9XoC0hc9@cvcluster.ljjpcws.mongodb.net/?retryWrites=true&w=majority&appName=CVCluster"

client = MongoClient(uri, server_api=ServerApi('1'))

try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

db = client['Images']
image_db = db['images_with_features']

sim = {}

for x in image_db.find({}, {"path": 0}):
    mse = mean_squared_error()