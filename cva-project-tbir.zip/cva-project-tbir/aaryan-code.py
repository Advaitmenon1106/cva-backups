import cv2
from cvzone.HandTrackingModule import HandDetector

## Button Class

class Button:
    def __init__(self, position, width, height, value):
        self.position = position
        self.width = width
        self.height = height
        self.value = value

    def draw(self, img):
        cv2.rectangle(img, self.position, (self.position[0] + self.width, self.position[1] + self.height), (225, 225, 225), cv2.FILLED)  ## Inner filling
        cv2.rectangle(img, self.position, (self.position[0] + self.width, self.position[1] + self.height), (25, 25, 25), 2)  ## Outer border
        cv2.putText(img, self.value, (self.position[0] + 40, self.position[1] + 40), cv2.FONT_HERSHEY_PLAIN, 2, (25, 25, 25), 1) ## Text Details

    def click(self, x, y):

        if self.position[0] < x < self.position[0] + self.width and \
            self.position[1] < y < self.position[1] + self.height:

            cv2.rectangle(img, self.position, (self.position[0] + self.width, self.position[1] + self.height), (255, 255, 255), cv2.FILLED)  ## Inner filling
            cv2.rectangle(img, self.position, (self.position[0] + self.width, self.position[1] + self.height), (25, 25, 25), 2)
            cv2.putText(img, self.value, (self.position[0] + 25, self.position[1] + 80), cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 0), 5)
            return True
        
        else:
            return False

## Creating buttons for calculator
button_list = []
button_values = [['7', '8', '9', '*'],
                 ['4', '5', '6', '-'],
                 ['1', '2', '3', '+'],
                 ['0', '/', '.', '=']]

for i in range(4):
    for j in range(4):
        # x_pos = i * 100 + 500 
        x_pos = i * 100 + 800
        # y_pos = j * 100 + 200
        y_pos = j * 100 + 150
        width = 100
        height = 100
        button_list.append(Button((x_pos, y_pos), 100, 100, button_values[j][i]))

## Equations and Values
eq = ''
counter = 0

## Webcam
cap = cv2.VideoCapture(0)
cap.set(3, 1280) ## width
cap.set(4, 720) ## height

detector = HandDetector(detectionCon = 0.6, maxHands = 1)

while True:
    _, img = cap.read()

    ## To flip the image
    img = cv2.flip(img, 1)

    ## Hand detection
    hands, img = detector.findHands(img, flipType = False)

    ## Drawing the answer button
    cv2.rectangle(img, (800, 50), (800 + 400, 70 + 100), (225, 225, 225), cv2.FILLED)  ## Inner filling
    cv2.rectangle(img, (800, 50), (800 + 400, 70 + 100), (25, 25, 25), 2)  ## Outer border

    ## Drawing the other buttons
    for button in button_list:
        button.draw(img)
        
    ## Pressing/Pinching
    if hands:
        lmList = hands[0]['lmList'] 
        # length, _, img = detector.findDistance(lmList[0], lmList[8], img)
        length, _, img = detector.findDistance(lmList[8], lmList[12], img)
        # print(length)

        x, y = lmList[8]

        if length < 50:
            for i, button in enumerate(button_list):
                if button.check(x, y) & counter == 0:
                    # Column | Row
                    value = button_values[int(i%4)][int(i/4)]
                    
                    if value == '=':
                        eq = str(eval(eq))
                    else:
                        eq += value 

                    counter += 1

    ## Avoid Duplicate values
    if counter != 0:
        counter += 1
        if counter > 10:
            counter = 0


    ## Carrying out the process of calci


    ## Display the equations/result
    cv2.putText(img, eq, (810, 120), cv2.FONT_HERSHEY_PLAIN, 2, (25, 25, 25), 1) ## Text Deta

    ## Display
    cv2.imshow('Image', img)

    key = cv2.waitKey(1)

    if key == ord('c'):
        eq = ''

    if key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
