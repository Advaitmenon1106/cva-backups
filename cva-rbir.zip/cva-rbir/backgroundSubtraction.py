import numpy as np
import cv2
import matplotlib.pyplot as plt
import imutils

path = 'training/ADE_train_00024717.jpg'

img = cv2.imread(path)
img = imutils.resize(img, width=600)
img2 = img.copy()

mask = np.zeros(img2.shape[:2],np.uint8)

bgdModel = np.zeros((1,65),np.float64)
fgdModel = np.zeros((1,65),np.float64)


rect = (115, 150, 480-115, 490-150)
cv2.grabCut(img2,mask,rect,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')
img2 = img2*mask2[:,:,np.newaxis]

cv2.imshow('original', img)
cv2.imshow('cropped', img2)
cv2.waitKey()
cv2.destroyAllWindows()

# plt.imshow(img)
# plt.show()