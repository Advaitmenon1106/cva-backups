import argparse
import cv2
import imutils
import numpy as np

image = cv2.imread('./images/house-pic-dan.jpg')
image = imutils.resize(image, width=600)

# initialize OpenCV's static saliency spectral residual detector and
# compute the saliency map
saliency = cv2.saliency.StaticSaliencySpectralResidual_create()
(success, saliencyMap) = saliency.computeSaliency(image)
saliencyMap = (saliencyMap * 255).astype("uint8")

# cv2.imshow("Image", image)
# cv2.imshow("Output", saliencyMap)
# cv2.waitKey(0)

# initialize OpenCV's static fine grained saliency detector and
# compute the saliency map
saliency = cv2.saliency.StaticSaliencyFineGrained_create()
(success, saliencyMap) = saliency.computeSaliency(image)
saliencyMap = (saliencyMap * 255).astype("uint8")
# if we would like a *binary* map that we could process for contours,
# compute convex hull's, extract bounding boxes, etc., we can
# additionally threshold the saliency map

threshMap = cv2.threshold(saliencyMap.astype("uint8"), 0, 255, type=cv2.THRESH_OTSU)[1]

kernel = np.ones((3, 3), dtype="uint8")
threshMap = cv2.morphologyEx(threshMap, cv2.MORPH_CLOSE, kernel)

cnts = cv2.findContours(threshMap.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cnts = cnts[0] if len(cnts) == 2 else cnts[1]  # Account for OpenCV version differences

rois = []
for c in cnts:
    x, y, w, h = cv2.boundingRect(c)
    rois.append((x, y, w, h))

for (x, y, w, h) in rois:
    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)


# show the images

cv2.imshow("Image", image)
cv2.imshow("Output", saliencyMap)
cv2.imshow("Thresh", threshMap)

cv2.waitKey(0)
