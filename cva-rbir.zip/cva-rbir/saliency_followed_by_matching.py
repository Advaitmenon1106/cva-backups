import psycopg2 as psg
import os
import numpy as np
import json
from skimage.feature import hog, SIFT, ORB
from skimage.color import rgb2gray
from skimage.io import imread
import cv2 
import imutils

def getSaliencymap(path):
    img = cv2.imread(path)
    img = imutils.resize(img, width=600)
    saliency = cv2.saliency.StaticSaliencyFineGrained_create() # type: ignore
    success, saliencyMap = saliency.computeSaliency(img)
    saliencyMap = (saliencyMap * 255).astype("uint8")
    threshMap = cv2.threshold(saliencyMap, 0, 255, type=cv2.THRESH_OTSU)[1]

    kernel = np.ones((3, 3), dtype="uint8")
    threshMap = cv2.morphologyEx(threshMap, cv2.MORPH_CLOSE, kernel)

    cnts = cv2.findContours(threshMap.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    roi_contour = max(cnts, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(roi_contour)

    cropped_image = img[y:y+h, x:x+w]
    return saliencyMap, threshMap, img, cropped_image

img1SaliencyMap, img1ThreshMap, orig1, roi1 = getSaliencymap('training/ADE_train_00014480.jpg')
img2SaliencyMap, img2ThreshMap, orig2, roi2 = getSaliencymap('training/ADE_train_00014484.jpg')

cnts1, hie1 = cv2.findContours(img1ThreshMap.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cnts2, hie2 = cv2.findContours(img2ThreshMap.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
print(cv2.matchShapes(cnts1[0], cnts2[0], 1, 0.0))

# cv2.drawContours(image=orig2, contours=cnts2, contourIdx=-1, color=(0, 255, 0), thickness=3)
# cv2.drawContours(image=orig1, contours=cnts1, contourIdx=-1, color=(0, 255, 0), thickness=3)


kp1, des1 = cv2.SIFT_create().detectAndCompute(roi1, None) # type: ignore

kp2, des2 = cv2.SIFT_create().detectAndCompute(roi2, None) # type: ignore

bfm = cv2.BFMatcher(crossCheck=True)

matches = bfm.match(des1, des2)
matches = sorted(matches, key=lambda x: x.distance)

img3 = cv2.drawMatches(orig1,kp1,orig2,kp2,matches[:10],None,flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

cv2.imshow('', img3)
cv2.waitKey()
cv2.destroyAllWindows()

