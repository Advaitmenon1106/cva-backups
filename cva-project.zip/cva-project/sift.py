import cv2
import matplotlib.pyplot as plt
import imutils

# Read an input image (you can replace 'input_image.jpg' with your own image path)
input_image = cv2.imread('./pexels-saleh-badawi-20852704.jpg', cv2.IMREAD_GRAYSCALE)
input_image = imutils.resize(input_image, width=500)

# Create a SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints and compute descriptors
keypoints, descriptors = sift.detectAndCompute(input_image, None)

# Visualize the keypoints on the image
output_image = cv2.drawKeypoints(input_image, keypoints, input_image)

# Display the result
cv2.imshow('', output_image)

if cv2.waitKey(0):
    cv2.destroyAllWindows()

print(descriptors)