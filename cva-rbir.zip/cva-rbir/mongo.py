from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from skimage.io import imread
from skimage.feature import hog
from skimage.color import rgb2gray
import imutils
import os

uri = "mongodb+srv://advait:W2WqMRvD9XoC0hc9@cvcluster.ljjpcws.mongodb.net/?retryWrites=true&w=majority&appName=CVCluster"

client = MongoClient(uri, server_api=ServerApi('1'))

try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

db = client['Images']
image_db = db['images_with_features']

c = 0

for img_path in os.listdir('./training'):
    try: greyscale = imread(f'./training/{img_path}')
    except:print(img_path)

    if len(greyscale.shape)>2:
        greyscale = rgb2gray(greyscale)

    greyscale = imutils.resize(greyscale, width=128)

    hog_ft = hog(greyscale)

    doc = {
        '_id': c,
        'path': img_path,
        'features': list(hog_ft)
    }
    c+=1
    image_db.insert_one(doc)


val = image_db.find_one({'id': 0})
print(val)